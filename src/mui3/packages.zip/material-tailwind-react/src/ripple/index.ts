import { RippleConfig } from './ripple-ref';
import {Ripple, RippleTarget} from './ripple';

import { useForwardedRef } from '../hooks/use-refs';
import { useState, ForwardedRef, useEffect, useRef, useCallback } from 'react';

export * from './ripple';
export * from './ripple-ref';
import style from './styles.module.scss';

export interface RippleProps<T> extends RippleConfig {
  ref: ForwardedRef<T> | undefined;
  disabled?: boolean;
  trigger?: HTMLElement;
}

export interface RippleResult<T extends HTMLElement> {
  setupElement: (element: HTMLElement) => void;
  ref: ForwardedRef<T>;
  className: string;
}

export function useRipple<T extends HTMLElement>(props: RippleProps<T>) : RippleResult<T> {
   const {ref, disabled, trigger, ...rest} = props;
   const elementRef = useForwardedRef<T>(props.ref);
   const rippleRef = useRef<Ripple|null>(null);

   const setupElement = useCallback((element: HTMLElement)=> {
       if (rippleRef.current) {
          rippleRef.current.setupElement(element);
       }
   }, [rippleRef.current]);

   useEffect(()=>{
      if(elementRef.current) {
        const rippleDisabled = disabled ?? !!(elementRef.current as any).disabled;
        rippleRef.current = new Ripple({rippleDisabled, ...rest} as unknown as RippleTarget, elementRef.current);
        rippleRef.current.setupElement(trigger ?? elementRef.current);
        return () => rippleRef.current.destroyElement(trigger ?? elementRef.current);
      }
      
   }, [elementRef, disabled, trigger]);

   return {
    ref: elementRef,
    setupElement,
    className: style['mat-ripple']
   } 

}