import alertOutlined from "../../alert/alertOutlined";

const outlined: object = alertOutlined;

export default outlined;
