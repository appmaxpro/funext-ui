import alertGradient from "../../alert/alertGradient";

const gradient: object = alertGradient;
export default gradient;
