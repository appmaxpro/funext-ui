import alertFilled from "../../alert/alertFilled";

const filled: object = alertFilled;

export default filled;
