import alertGhost from "../../alert/alertGhost";

const ghost: object = alertGhost;

export default ghost;
