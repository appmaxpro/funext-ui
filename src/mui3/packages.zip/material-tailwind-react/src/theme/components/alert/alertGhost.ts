const alertGhost: object = {
  transparent: {
    bg: "bg-transparent",
    color: "text-blue-gray-900",
  },
  white: {
    color: "text-white",
    background: "bg-white/10",
  },
  primary: {
    bg: "bg-primary-500/20",
    color: "bg-primary-900",
  },
  "blue-gray": {
    bg: "bg-blue-gray-500/20",
    color: "text-blue-gray-900",
  },
  gray: {
    bg: "bg-gray-900/10",
    color: "text-gray-900",
  },
  brown: {
    bg: "bg-brown-500/20",
    color: "text-brown-900",
  },
  "deep-orange": {
    bg: "bg-deep-orange-500/20",
    color: "text-deep-orange-900",
  },
  orange: {
    bg: "bg-orange-500/20",
    color: "text-orange-900",
  },
  amber: {
    bg: "bg-amber-500/20",
    color: "text-amber-900",
  },
  yellow: {
    bg: "bg-yellow-500/20",
    color: "text-yellow-900",
  },
  lime: {
    bg: "bg-lime-500/20",
    color: "text-lime-900",
  },
  "light-green": {
    bg: "bg-light-green-500/20",
    color: "text-light-green-900",
  },
  green: {
    bg: "bg-green-500/20",
    color: "text-green-900",
  },
  teal: {
    bg: "bg-teal-500/20",
    color: "text-teal-900",
  },
  cyan: {
    bg: "bg-cyan-500/20",
    color: "text-cyan-900",
  },
  "light-blue": {
    bg: "bg-light-blue-500/20",
    color: "text-light-blue-900",
  },
  blue: {
    bg: "bg-blue-500/20",
    color: "text-blue-900",
  },
  indigo: {
    bg: "bg-indigo-500/20",
    color: "text-indigo-900",
  },
  "deep-purple": {
    bg: "bg-deep-purple-500/20",
    color: "text-deep-purple-900",
  },
  purple: {
    bg: "bg-purple-500/20",
    color: "text-purple-900",
  },
  pink: {
    bg: "bg-pink-500/20",
    color: "text-pink-900",
  },
  red: {
    bg: "bg-red-500/20",
    color: "text-red-900",
  },
};

export default alertGhost;
