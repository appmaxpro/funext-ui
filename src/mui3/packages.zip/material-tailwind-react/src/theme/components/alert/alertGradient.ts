const alertGradient: object = {
  transparent: {
    bg: "bg-transparent",
    color: "text-blue-gray-900",
  },
  white: {
    bg: "bg-white",
    color: "text-blue-gray-900",
  },
  primary: {
    bg: "bg-gradient-to-tr from-primary-600 to-primary-400",
    color: "text-white",
  },
  "blue-gray": {
    bg: "bg-gradient-to-tr from-blue-gray-600 to-blue-gray-400",
    color: "text-white",
  },
  gray: {
    bg: "bg-gradient-to-tr from-gray-900 to-gray-800",
    color: "text-white",
  },
  brown: {
    bg: "bg-gradient-to-tr from-brown-600 to-brown-400",
    color: "text-white",
  },
  "deep-orange": {
    bg: "bg-gradient-to-tr from-deep-orange-600 to-deep-orange-400",
    color: "text-white",
  },
  orange: {
    bg: "bg-gradient-to-tr from-orange-600 to-orange-400",
    color: "text-white",
  },
  amber: {
    bg: "bg-gradient-to-tr from-amber-600 to-amber-400",
    color: "text-black",
  },
  yellow: {
    bg: "bg-gradient-to-tr from-yellow-600 to-yellow-400",
    color: "text-black",
  },
  lime: {
    bg: "bg-gradient-to-tr from-lime-600 to-lime-400",
    color: "text-black",
  },
  "light-green": {
    bg: "bg-gradient-to-tr from-light-green-600 to-light-green-400",
    color: "text-white",
  },
  green: {
    bg: "bg-gradient-to-tr from-green-600 to-green-400",
    color: "text-white",
  },
  teal: {
    bg: "bg-gradient-to-tr from-teal-600 to-teal-400",
    color: "text-white",
  },
  cyan: {
    bg: "bg-gradient-to-tr from-cyan-600 to-cyan-400",
    color: "text-white",
  },
  "light-blue": {
    bg: "bg-gradient-to-tr from-light-blue-600 to-light-blue-400",
    color: "text-white",
  },
  blue: {
    bg: "bg-gradient-to-tr from-blue-600 to-blue-400",
    color: "text-white",
  },
  indigo: {
    bg: "bg-gradient-to-tr from-indigo-600 to-indigo-400",
    color: "text-white",
  },
  "deep-purple": {
    bg: "bg-gradient-to-tr from-deep-purple-600 to-deep-purple-400",
    color: "text-white",
  },
  purple: {
    bg: "bg-gradient-to-tr from-purple-600 to-purple-400",
    color: "text-white",
  },
  pink: {
    bg: "bg-gradient-to-tr from-pink-600 to-pink-400",
    color: "text-white",
  },
  red: {
    bg: "bg-gradient-to-tr from-red-600 to-red-400",
    color: "text-white",
  },
};

export default alertGradient;
