const alertFilled: object = {
  transparent: {
    bg: "bg-transparent",
    color: "text-blue-gray-900",
  },
  white: {
    bg: "bg-white",
    color: "text-blue-gray-900",
  },
  primary: {
    bg: "bg-primary-500",
    color: "text-white",
  },
  "blue-gray": {
    bg: "bg-blue-gray-500",
    color: "text-white",
  },
  gray: {
    bg: "bg-gray-900",
    color: "text-white",
  },
  brown: {
    bg: "bg-brown-500",
    color: "text-white",
  },
  "deep-orange": {
    bg: "bg-deep-orange-500",
    color: "text-white",
  },
  orange: {
    bg: "bg-orange-500",
    color: "text-white",
  },
  amber: {
    bg: "bg-amber-500",
    color: "text-black",
  },
  yellow: {
    bg: "bg-yellow-500",
    color: "text-black",
  },
  lime: {
    bg: "bg-lime-500",
    color: "text-black",
  },
  "light-green": {
    bg: "bg-light-green-500",
    color: "text-white",
  },
  green: {
    bg: "bg-green-500",
    color: "text-white",
  },
  teal: {
    bg: "bg-teal-500",
    color: "text-white",
  },
  cyan: {
    bg: "bg-cyan-500",
    color: "text-white",
  },
  "light-blue": {
    bg: "bg-light-blue-500",
    color: "text-white",
  },
  blue: {
    bg: "bg-blue-500",
    color: "text-white",
  },
  indigo: {
    bg: "bg-indigo-500",
    color: "text-white",
  },
  "deep-purple": {
    bg: "bg-deep-purple-500",
    color: "text-white",
  },
  purple: {
    bg: "bg-purple-500",
    color: "text-white",
  },
  pink: {
    bg: "bg-pink-500",
    color: "text-white",
  },
  red: {
    bg: "bg-red-500",
    color: "text-white",
  },
};

export default alertFilled;
