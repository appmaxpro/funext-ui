import sliderColor from "../slider/sliderColor";

const spinnerColor: object = sliderColor

export default spinnerColor;
