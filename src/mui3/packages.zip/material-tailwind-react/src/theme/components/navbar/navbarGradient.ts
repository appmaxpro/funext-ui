import alertGradient from "../alert/alertGradient";

const navbarGradient: object = alertGradient;

export default navbarGradient;
