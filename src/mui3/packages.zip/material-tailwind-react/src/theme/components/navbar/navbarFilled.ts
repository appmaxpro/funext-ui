import alertFilled from "../alert/alertFilled";
const navbarFilled: object = alertFilled;

export default navbarFilled;
