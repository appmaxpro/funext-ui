import inputOutlinedLabel from "./inputOutlinedLabel";
import inputOutlinedColors from "./inputOutlinedColors";
import inputOutlinedLabelColors from "./inputOutlinedLabelColors";
import styles from './outline.module.scss';
import { className } from '../../../../types/components/accordion';

console.log("outline-module.css:", styles);

const inputOutlined = {
  styles,
  base: {
    input: {
      borderWidth: "outline-0",
      borderColor: "outline-gray-200",
      floated: {
        borderColor: "focus-within:outline-primary:500",
      },
    },
    inputFloated:{
      borderColor: "outline-primary:500",
    },
    native:{
      placeholder: "placeholder:opacity-0 focus:placeholder:opacity-100",
    },
    nativeFloated:{
      placeholder: "opacity-100",
    },
    label: {
      position: "-top-1.5",
      fontSize: "text-sm",
      className: styles['label'],
    },
    labelFloated: {
      color: "text-primary:500",
      className: `${styles['label']} ${styles['floated']}`
    },
    notched: {
      className: styles['notched'],

    }
  },
  sizes: {
    md: {
      container: {
        height: "h-10",
      },
      input: {
        fontSize: "text-sm",
        borderRadius: "rounded-[7px]",
      },
      label: {
        lineHeight: "leading-[3.75]",
      },
      notched: {
        px: "px-3",
        py: "py-2.5",
      }
    },
    lg: {
      container: {
        height: "h-11",
      },
      input: {
        fontSize: "text-sm",
        px: "px-3",
        py: "py-3",
        borderRadius: "rounded-md",
      },
      label: {
        lineHeight: "peer-placeholder-shown:leading-[4.1]",
      },
      notched: {
        px: "px-3",
        py: "py-3",
      }
    },
  },
  colors: {
    input: inputOutlinedColors,
    label: inputOutlinedLabelColors,
  },
  error: {
    input: {
      borderColor: "border-red-500",
      borderColorFocused: "focus-within:border-red-500",
    },
    label: {
      color: "text-red-500 peer-focus-within:text-red-500"
    },
    native:{
      placeholder: "placeholder:opacity-0 focus:placeholder:opacity-100",
    }
  },
  success: {
    input: {
      borderColor: "border-green-500 ",
      borderColorFocused: "focus-within:border-green-500",
    },
    label: {
      color: "text-green-500 peer-focus-within:text-green-500"
    },
    native:{
      placeholder: "placeholder-shown:border-green-500 placeholder-shown:border-green-500",
    }
  },
  shrink: {
    label: {
      fontSize: "!text-[11px]",
      lineHeight: "!leading-tight"
    },
  },
};

export default inputOutlined;
