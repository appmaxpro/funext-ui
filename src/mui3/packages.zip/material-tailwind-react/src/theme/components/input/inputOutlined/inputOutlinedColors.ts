const inputOutlinedColors: object = {
  black: {
    color: "text-black",
    borderColor: "border-black",
    borderColorFocused: "focus-within:border-black",
  },
  white: {
    color: "!text-white",
    borderColor: "border-white",
    borderColorFocused: "focus-within:border-white",
  },
  primary: {
    borderColor: "border-primary-200",
    borderColorFocused: "focus-within:border-primary-500",
  },
  "blue-gray": {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-blue-gray-500",
  },
  gray: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-gray-900",
  },
  brown: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-brown-500",
  },
  "deep-orange": {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-deep-orange-500",
  },
  orange: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-orange-500",
  },
  amber: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-amber-500",
  },
  yellow: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-yellow-500",
  },
  lime: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-lime-500",
  },
  "light-green": {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-light-green-500",
  },
  green: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-green-500",
  },
  teal: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-teal-500",
  },
  cyan: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-cyan-500",
  },
  "light-blue": {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-light-blue-500",
  },
  blue: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-blue-500",
  },
  indigo: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-indigo-500",
  },
  "deep-purple": {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-deep-purple-500",
  },
  purple: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-purple-500",
  },
  pink: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-pink-500",
  },
  red: {
    borderColor: "border-blue-gray-200",
    borderColorFocused: "focus-within:border-red-500",
  },
};

export default inputOutlinedColors;
