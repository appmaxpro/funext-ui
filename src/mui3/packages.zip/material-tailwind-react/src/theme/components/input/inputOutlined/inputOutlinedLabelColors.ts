
const inputOutlinedLabelColors: object = {
  black: {
    color: "!text-black peer-focus-within:text-black"
  },
  white: {
    color: "!text-white peer-focus-within:text-white"
  },
  primary: {
    color: "text-gray-400 peer-focus-within:text-primary-500"
  },
  "blue-gray": {
    color: "text-gray-400 peer-focus-within:text-blue-gray-500"
  },
  gray: {
    color: "text-gray-500 peer-focus-within:text-gray-900"
  },
  brown: {
    color: "text-gray-400 peer-focus-within:text-brown-500"
  },
  "deep-orange": {
    color: "text-gray-400 peer-focus-within:text-deep-orange-500"
  },
  orange: {
    color: "text-gray-400 peer-focus-within:text-orange-500"
  },
  amber: {
    color: "text-gray-400 peer-focus-within:text-amber-500"
  },
  yellow: {
    color: "text-gray-400 peer-focus-within:text-yellow-500"
  },
  lime: {
    color: "text-gray-400 peer-focus-within:text-lime-500"
  },
  "light-green": {
    color: "text-gray-400 peer-focus-within:text-light-green-500"
  },
  green: {
    color: "text-gray-400 peer-focus-within:text-green-500"
  },
  teal: {
    color: "text-gray-400 peer-focus-within:text-teal-500"
  },
  cyan: {
    color: "text-gray-400 peer-focus-within:text-cyan-500"
  },
  "light-blue": {
    color: "text-gray-400 peer-focus-within:text-light-blue-500"
  },
  blue: {
    color: "text-gray-400 peer-focus-within:text-blue-500"
  },
  indigo: {
    color: "text-gray-400 peer-focus-within:text-indigo-500"
  },
  "deep-purple": {
    color: "text-gray-400 peer-focus-within:text-deep-purple-500"
  },
  purple: {
    color: "text-gray-400 peer-focus-within:text-purple-500"
  },
  pink: {
    color: "text-gray-400 peer-focus-within:text-pink-500"
  },
  red: {
    color: "text-gray-400 peer-focus-within:text-red-500"
  },
};

export default inputOutlinedLabelColors;
