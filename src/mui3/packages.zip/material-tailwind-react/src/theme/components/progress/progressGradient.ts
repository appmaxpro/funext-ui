import alertGradient from "../alert/alertGradient";
const progressGradient: object = alertGradient;

export default progressGradient;
