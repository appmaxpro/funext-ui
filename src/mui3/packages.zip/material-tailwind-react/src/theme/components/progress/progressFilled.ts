import alertFilled from "../alert/alertFilled";
const progressFilled: object = alertFilled;

export default progressFilled;
