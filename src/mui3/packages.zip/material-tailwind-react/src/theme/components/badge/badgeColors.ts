import alertFilled from "../alert/alertFilled";

const badgeColors: object = alertFilled;

export default badgeColors;
