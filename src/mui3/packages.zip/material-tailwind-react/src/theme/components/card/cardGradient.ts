const cardGradient: object = {
  transparent: {
    bg: "bg-transparent",
    color: "text-gray-700",
    shadow: "shadow-none",
  },
  white: {
    bg: "bg-white",
    color: "text-gray-700",
  },
  primary: {
    bg: "bg-gradient-to-tr from-primary-600 to-primary-400",
    color: "text-white",
    shadow: "shadow-primary/40",
  },
  "blue-gray": {
    bg: "bg-gradient-to-tr from-blue-gray-600 to-blue-gray-400",
    color: "text-white",
    shadow: "shadow-blue-gray-500/40",
  },
  gray: {
    bg: "bg-gradient-to-tr from-gray-900 to-gray-800",
    color: "text-white",
    shadow: "shadow-gray-900/20",
  },
  brown: {
    bg: "bg-gradient-to-tr from-brown-600 to-brown-400",
    color: "text-white",
    shadow: "shadow-brown-500/40",
  },
  "deep-orange": {
    bg: "bg-gradient-to-tr from-deep-orange-600 to-deep-orange-400",
    color: "text-white",
    shadow: "shadow-deep-orange-500/40",
  },
  orange: {
    bg: "bg-gradient-to-tr from-orange-600 to-orange-400",
    color: "text-white",
    shadow: "shadow-orange-500/40",
  },
  amber: {
    bg: "bg-gradient-to-tr from-amber-600 to-amber-400",
    color: "text-gray-700",
    shadow: "shadow-amber-500/40",
  },
  yellow: {
    bg: "bg-gradient-to-tr from-yellow-600 to-yellow-400",
    color: "text-gray-700",
    shadow: "shadow-yellow-500/40",
  },
  lime: {
    bg: "bg-gradient-to-tr from-lime-600 to-lime-400",
    color: "text-gray-700",
    shadow: "shadow-lime-500/40",
  },
  "light-green": {
    bg: "bg-gradient-to-tr from-light-green-600 to-light-green-400",
    color: "text-white",
    shadow: "shadow-light-green-500/40",
  },
  green: {
    bg: "bg-gradient-to-tr from-green-600 to-green-400",
    color: "text-white",
    shadow: "shadow-green-500/40",
  },
  teal: {
    bg: "bg-gradient-to-tr from-teal-600 to-teal-400",
    color: "text-white",
    shadow: "shadow-teal-500/40",
  },
  cyan: {
    bg: "bg-gradient-to-tr from-cyan-600 to-cyan-400",
    color: "text-white",
    shadow: "shadow-cyan-500/40",
  },
  "light-blue": {
    bg: "bg-gradient-to-tr from-light-blue-600 to-light-blue-400",
    color: "text-white",
    shadow: "shadow-light-blue-500/40",
  },
  blue: {
    bg: "bg-gradient-to-tr from-blue-600 to-blue-400",
    color: "text-white",
    shadow: "shadow-blue-500/40",
  },
  indigo: {
    bg: "bg-gradient-to-tr from-indigo-600 to-indigo-400",
    color: "text-white",
    shadow: "shadow-indigo-500/40",
  },
  "deep-purple": {
    bg: "bg-gradient-to-tr from-deep-purple-600 to-deep-purple-400",
    color: "text-white",
    shadow: "shadow-deep-purple-500/40",
  },
  purple: {
    bg: "bg-gradient-to-tr from-purple-600 to-purple-400",
    color: "text-white",
    shadow: "shadow-purple-500/40",
  },
  pink: {
    bg: "bg-gradient-to-tr from-pink-600 to-pink-400",
    color: "text-white",
    shadow: "shadow-pink-500/40",
  },
  red: {
    bg: "bg-gradient-to-tr from-red-600 to-red-400",
    color: "text-white",
    shadow: "shadow-red-500/40",
  },
};

export default cardGradient;
