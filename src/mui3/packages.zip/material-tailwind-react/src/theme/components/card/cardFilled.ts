const cardFilled: object = {
  transparent: {
    bg: "bg-transparent",
    color: "text-gray-700",
    shadow: "shadow-none",
  },
  white: {
    bg: "bg-white",
    color: "text-gray-700",
  },
  primary: {
    bg: "bg-primary",
    color: "text-white",
    shadow: "shadow-primary/40",
  },
  "blue-gray": {
    bg: "bg-blue-gray-500",
    color: "text-white",
    shadow: "shadow-blue-gray-500/40",
  },
  gray: {
    bg: "bg-gray-900",
    color: "text-white",
    shadow: "shadow-gray-900/20",
  },
  brown: {
    bg: "bg-brown-500",
    color: "text-white",
    shadow: "shadow-brown-500/40",
  },
  "deep-orange": {
    bg: "bg-deep-orange-500",
    color: "text-white",
    shadow: "shadow-deep-orange-500/40",
  },
  orange: {
    bg: "bg-orange-500",
    color: "text-white",
    shadow: "shadow-orange-500/40",
  },
  amber: {
    bg: "bg-amber-500",
    color: "text-gray-700",
    shadow: "shadow-amber-500/40",
  },
  yellow: {
    bg: "bg-yellow-500",
    color: "text-gray-700",
    shadow: "shadow-yellow-500/40",
  },
  lime: {
    bg: "bg-lime-500",
    color: "text-gray-700",
    shadow: "shadow-lime-500/40",
  },
  "light-green": {
    bg: "bg-light-green-500",
    color: "text-white",
    shadow: "shadow-light-green-500/40",
  },
  green: {
    bg: "bg-green-500",
    color: "text-white",
    shadow: "shadow-green-500/40",
  },
  teal: {
    bg: "bg-teal-500",
    color: "text-white",
    shadow: "shadow-teal-500/40",
  },
  cyan: {
    bg: "bg-cyan-500",
    color: "text-white",
    shadow: "shadow-cyan-500/40",
  },
  "light-blue": {
    bg: "bg-light-blue-500",
    color: "text-white",
    shadow: "shadow-light-blue-500/40",
  },
  blue: {
    bg: "bg-blue-500",
    color: "text-white",
    shadow: "shadow-blue-500/40",
  },
  indigo: {
    bg: "bg-indigo-500",
    color: "text-white",
    shadow: "shadow-indigo-500/40",
  },
  "deep-purple": {
    bg: "bg-deep-purple-500",
    color: "text-white",
    shadow: "shadow-deep-purple-500/40",
  },
  purple: {
    bg: "bg-purple-500",
    color: "text-white",
    shadow: "shadow-purple-500/40",
  },
  pink: {
    bg: "bg-pink-500",
    color: "text-white",
    shadow: "shadow-pink-500/40",
  },
  red: {
    bg: "bg-red-500",
    color: "text-white",
    shadow: "shadow-red-500/40",
  },
};

export default cardFilled;
