import alertGhost from "../alert/alertGhost";


const chipGhost: object = alertGhost;

export default chipGhost;
