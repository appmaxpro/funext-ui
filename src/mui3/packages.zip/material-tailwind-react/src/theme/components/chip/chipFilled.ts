import alertFilled from "../alert/alertFilled";

const chipFilled: object = alertFilled;

export default chipFilled;
