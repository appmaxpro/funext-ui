import alertOutlined from "../alert/alertOutlined";

const chipOutlined: object =alertOutlined;

export default chipOutlined;
