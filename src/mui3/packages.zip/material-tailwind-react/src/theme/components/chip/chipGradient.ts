import alertGradient from "../alert/alertGradient";

const chipGradient: object = alertGradient;

export default chipGradient;
