import sliderColor from "../slider/sliderColor";

const ratingColors: object = sliderColor;

export default ratingColors;
