import React, { useState, useRef, useEffect } from "react";
import PropTypes from "prop-types";

// utils
import classnames from "classnames";
import findMatch from "../../utils/findMatch";
import objectsToString from "../../utils/objectsToString";

// context
import { useTheme } from "../../context/theme";

// types
import type {
  variant,
  color,
  size,
  label,
  error,
  success,
  icon,
  labelProps,
  containerProps,
  shrink,
  className,
} from "../../types/components/input";
import {
  propTypesVariant,
  propTypesColor,
  propTypesSize,
  propTypesLabel,
  propTypesError,
  propTypesSuccess,
  propTypesIcon,
  propTypesLabelProps,
  propTypesContainerProps,
  propTypesShrink,
  propTypesClassName,
} from "../../types/components/input";
import { twMerge } from "tailwind-merge";
import { useRefs, useForwardedRef } from "../../hooks/use-refs";
import { className } from '../../types/components/accordion';

export interface BasicInputProps {
  variant?: variant;
  size?: size;
  color?: color;
  label?: label;
  error?: error;
  success?: success;
  icon?: icon;
  labelProps?: labelProps;
  containerProps?: containerProps;
  className?: className;
  shrink?: shrink;
  inputRef?: React.Ref<HTMLInputElement>;
  multiLines?: boolean;
  resize?:boolean;
  startAdornment?: React.ReactNode;
  endAdornment?: React.ReactNode;
}

export interface SingleInputProps extends BasicInputProps,
   Omit<React.ComponentProps<"input">, "size" | "type" | "color"> {
  type?: React.ComponentProps<"input">['type'];
}

export interface TextareaProps extends BasicInputProps, Omit<React.ComponentProps<"textarea">, "size" | "color">{
  resize?:boolean;
  multiLines?: boolean;
}

export declare type InputProps = SingleInputProps | TextareaProps;

declare type OtherInputProps = InputProps & {hasFocus: boolean};


export const Input = React.forwardRef<HTMLInputElement, OtherInputProps & {css:any}>(
  (
    {
      variant,
      color,
      size,
      label,
      error,
      success,
      icon,
      containerProps,
      labelProps,
      className,
      shrink,
      inputRef:provInputRef,
      type,
      css,
      resize,
      multiLines,
      startAdornment,
      endAdornment,
      ...rest
    },
    ref,
  ) => {
    // 1. init
    const { input } = useTheme();
    const { defaultProps, valid, styles, onFocus, onBlur } = input;
    const { base, variants } = styles;
    
    const myInputRef = useRef();

    const inputRef = useRefs(myInputRef, provInputRef)

    const [focus, setFocus] = useState(false);
    
    const handleFocus = (event:any) => {
      setFocus(true);
      onFocus?.(event);
    }

    const handleBlur = (event:any) => {
      setFocus(false);
      onBlur?.(event);
    }


    // 2. set default props
    variant = variant ?? defaultProps.variant;
    size = size ?? defaultProps.size;
    color = color ?? defaultProps.color;
    label = label ?? defaultProps.label;
    labelProps = labelProps ?? defaultProps.labelProps;
    containerProps = containerProps ?? defaultProps.containerProps;
    shrink = shrink ?? defaultProps.shrink;
    icon = icon ?? defaultProps.icon;
    className = twMerge(defaultProps.className || "", className);
    const hasAdornments = startAdornment || endAdornment;

    //(rest as React.ComponentProps<"input">).type
    // 3. set styles
    const inputVariant = variants[findMatch(valid.variants, variant, "outlined")];
    const inputSize = inputVariant.sizes[findMatch(valid.sizes, size, "md")];
    const adornments = (base.adornments || {}) as any;
    const startAdornmentsClasses = objectsToString(adornments.start);
    const endAdornmentsClasses = objectsToString(adornments.end);

    const inputError = objectsToString(inputVariant.error.input);
    const inputSuccess = objectsToString(inputVariant.success.input);
    const inputShrink = objectsToString(inputVariant.shrink.input);
    const inputColor = objectsToString(
      inputVariant.colors.input[findMatch(valid.colors, color, "primary")],
    );

    const props = { 
      [objectsToString(adornments.props)]: hasAdornments ,
      [inputColor]: !error && !success ,
      [inputError]: error ,
      [inputSuccess]: success ,
      [inputShrink]: shrink  || focus || rest.value,
      [adornments.className]: hasAdornments
     };

    const containerClasses = classnames(
      objectsToString(base.container),
      objectsToString(inputSize.container),
      containerProps?.className,
      {'has-focus': focus}
    );

    const inputClasses = classnames(
      objectsToString(base.input),
      objectsToString(inputVariant.base.input),
      objectsToString(inputSize.input),
      props,
      (multiLines && !resize) ? "!resize-none" : "",
      className,
    );

    const native = {...base.native, ...inputVariant.base.native} ;
     


    let labelClasses ;
    if(label) {
      const labelError = objectsToString(inputVariant.error.label);
      const labelSuccess = objectsToString(inputVariant.success.label);
      const labelShrink = objectsToString(inputVariant.shrink.label);
      const labelColor = objectsToString(
        inputVariant.colors.label[findMatch(valid.colors, color, "primary")],
      );

      const inputShrink = shrink  || focus || rest.value;

      const labelFloated = inputShrink ? inputVariant.base.labelFloated : null ;
      let labelFocus = focus && !error && !success 
            ? labelColor.split(' ').pop()
            : null;
      if (labelFocus) {
        labelFocus = labelFocus.split(':').pop()
      }

      labelClasses = classnames(
          objectsToString(base.label),
          objectsToString({...inputVariant.base.label, ...labelFloated}),
          objectsToString(inputSize.label),
          {
            [labelColor]: !error && !success ,
            [labelError]: error ,
            [labelSuccess]: success ,
            [labelShrink]: shrink  || focus || rest.value,
            labelFocus
          },
          labelProps?.className
        );
    } else {
      labelClasses = null;
    }
    
    const iconClasses = classnames(
      objectsToString(base.icon),
      objectsToString(inputVariant.base.icon),
      objectsToString(inputSize.icon),
    );
    const asteriskClasses = classnames(objectsToString(base.asterisk));

    const nativeClassName = classnames(objectsToString(native));

    useEffect(()=> {
      const isFocused = (document.activeElement === inputRef.current);
      setFocus(isFocused)
    }, [inputRef.current])


    // 4. return

    return (
      <div {...containerProps} ref={ref} className={containerClasses}>
        {label && <label {...labelProps} className={labelClasses}>
                {label} {rest.required ? <span className={asteriskClasses}>*</span> : ""}
          </label>
        }
        <div className={inputClasses}>
          { startAdornment
            ? <div className={startAdornmentsClasses}>{startAdornment}</div>
            : null
          }
          {multiLines 
            ? <textarea 
                {...(rest as React.ComponentProps<"textarea">)} 
                ref={inputRef}
                className={nativeClassName} 
                placeholder={rest?.placeholder || " "} 
                onFocus={handleFocus}
                onBlur={handleBlur}
              />
            : <input
                {...(rest as React.ComponentProps<"input">)}
                ref={inputRef}
                className={nativeClassName}
                placeholder={rest?.placeholder || " "}
                type={type}
                onFocus={handleFocus}
                onBlur={handleBlur}
              />
          }
          { endAdornment
            ? <div className={endAdornmentsClasses}>{endAdornment}</div>
            : null
          }
          { variant === 'outlined' && label
              ? <fieldset className={classnames(objectsToString(inputVariant.base.notched))}>
                  <legend>
                    <span>{label}</span>
                  </legend>
                </fieldset>
              : null
          }
        </div>
        
      </div>
    );
  },
);

Input.propTypes = {
  variant: PropTypes.oneOf(propTypesVariant),
  size: PropTypes.oneOf(propTypesSize),
  color: PropTypes.oneOf(propTypesColor),
  label: propTypesLabel,
  error: propTypesError,
  success: propTypesSuccess,
  icon: propTypesIcon,
  labelProps: propTypesLabelProps,
  containerProps: propTypesContainerProps,
  shrink: propTypesShrink,
  className: propTypesClassName,
  type: PropTypes.string,
  resize: PropTypes.bool,
  multiLines: PropTypes.bool,
};

Input.displayName = "MaterialTailwind.Input";




export default Input;
